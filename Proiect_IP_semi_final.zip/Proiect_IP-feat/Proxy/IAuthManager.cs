﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proxy
{
    internal interface IAuthManager
    {
        public bool UserExists(string user);
        public void AddUser(string user, string pass);
    }
}
