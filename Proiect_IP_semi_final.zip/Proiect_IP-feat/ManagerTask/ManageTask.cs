﻿using System;
using System.Collections.Generic;
using Task;

namespace ManagerTask
{
    public sealed class ManageClass
    {
        static ManageClass _instance = null;

        public List<TaskClass> listTask;

        private ManageClass()
        {
            listTask = new List<TaskClass>();
        }

        public static ManageClass Instance()
        {
            if (_instance == null)
                _instance = new ManageClass();
            return _instance;
        }

        public string AddTask(TaskClass t)
        {
            if (Contains(t))
            {
                return "Exista deja";
            }
            listTask.Add(t);
            return "task adaugat";
        }

        public string DeleteTask(TaskClass t)
        {
            for (int i = 0; i < listTask.Count; i++)
            {
                if (t.TaskName == listTask[i].TaskName)
                {
                    listTask.RemoveAt(i);
                    return "Task Sters";
                }
            }
            return "Task inexistent";
        }

        private bool Contains(TaskClass t)
        {
            for (int i = 0; i < listTask.Count; i++)
            {
                if (t.TaskName == listTask[i].TaskName)
                    return true;
            }
            return false;
        }
    }
}
