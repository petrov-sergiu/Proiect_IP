/**************************************************************************
*                                                                        *
*  File:        loginPage.cs                                             *
*  Copyright:   (c) 2021, Lefter Ioan-Alexandru                          *
*               (c) 2021, Maftei Eduard-Ionut                            *
*  E-mail:      ioan-alexandru.lefter@student.tuiasi.ro                  *
*  E-mail:      eduard-ionut.maftei@student.tuiasi.ro                    *
*  Description: Tester                                                   *
*  This program is free software; you can redistribute it and/or modify  *
*  it under the terms of the GNU General Public License as published by  *
*  the Free Software Foundation. This program is distributed in the      *
*  hope that it will be useful, but WITHOUT ANY WARRANTY; without even   *
*  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   *
*  PURPOSE. See the GNU General Public License for more details.         *
*                                                                        *
**************************************************************************/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Interfata;
using System;
using System.Xml.Linq;

namespace tester
{
    /// <summary>
    /// Clasa de teste
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        #region Methods

        [TestMethod]
        public void XML_exists()
        {
            Assert.AreEqual(true, System.IO.File.Exists(@"C:\Users\Lefte\Desktop\IP PROIECT\Interfata\Interfata\bin\Debug\net5.0-windows\utilizatori.xml"));
        }

        [TestMethod]
        public void XML_Load()
        {
            Assert.AreNotEqual(null, XDocument.Load(@"C:\Users\Lefte\Desktop\IP PROIECT\Interfata\Interfata\bin\Debug\net5.0-windows\utilizatori.xml"));
        }

        [TestMethod]
        public void XML_notnull()
        {
            XDocument Xdoc = new XDocument(new XElement("Users"));
            Xdoc = XDocument.Load(@"C:\Users\Lefte\Desktop\IP PROIECT\Interfata\Interfata\bin\Debug\net5.0-windows\utilizatori.xml");
            Assert.AreNotEqual(null, Xdoc.Descendants().ToString());
        }

        #endregion Methods
    }
}
