﻿/**************************************************************************
 *                                                                        *
 *  File:        Form1.cs                                                 *
 *  Copyright:   (c) 2021, Maftei Eduard-Ionut                            *
 *  Interface:   Prodan Oana-Elena                                        *
 *  E-mail:      eduard-ionut.maftei@student.tuiasi.ro                    *
 *  Description: Pagina principala care permite utilizatorului sa acceseze*
 *                un chestionar, sa se delogheze sau sa inchida aplicatia *
 *                                                                        *
 *  This program is free software; you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation. This program is distributed in the      *
 *  hope that it will be useful, but WITHOUT ANY WARRANTY; without even   *
 *  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   *
 *  PURPOSE. See the GNU General Public License for more details.         *
 *                                                                        *
 **************************************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfata
{
    /// <summary>
    /// Creaza o pagina principala, de unde utilizatorul are acces la chestionar, poate sa se delogheze sau sa inchida aplicatia
    /// </summary>
    public partial class MainPage : Form
    {
        #region Constructors
        public MainPage()
        {
           InitializeComponent();
        }
        #endregion Constructors

        #region Events

        /// <summary>
        /// In momentul logarii, pe pagina Main va aparea un mesaj de salutare individual pentru fiecare user;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainPage_Load(object sender, EventArgs e)
        { 
            label2.Text = PassInfo._userName + "!";
        }


        /// <summary>
        /// Cand se apasa butonul "Inchide", aplicatia se va inchide;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }


        /// <summary>
        /// La apasare, se deschide chestionarul;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        /// <summary>
        /// Cand se apasa butonul de delogare, ne va trimite inapoi la pagina de login si ascunde pagina Main;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            loginPage loginPage = new loginPage();
            loginPage.Show();
            this.Hide(); 
        }


        /// <summary>
        /// Inchiderea aplicatiei pentru ca dupa un nr. de accesari rula pe fundal si era imposibila deschidea acestuia din nou;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void form_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        #endregion Events
    }
}
