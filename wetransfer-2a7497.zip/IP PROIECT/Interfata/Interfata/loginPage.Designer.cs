﻿
namespace Interfata
{
    partial class loginPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginButton = new System.Windows.Forms.Button();
            this.registerButton = new System.Windows.Forms.Button();
            this.passBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.userBox = new System.Windows.Forms.TextBox();
            this.About_menu = new System.Windows.Forms.MenuStrip();
            this.about_strip = new System.Windows.Forms.ToolStripMenuItem();
            this.About_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginButton
            // 
            this.loginButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.loginButton.Location = new System.Drawing.Point(161, 221);
            this.loginButton.Name = "loginButton";
            this.loginButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.loginButton.Size = new System.Drawing.Size(135, 39);
            this.loginButton.TabIndex = 0;
            this.loginButton.Text = "LOGIN";
            this.loginButton.UseVisualStyleBackColor = true;
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
            // 
            // registerButton
            // 
            this.registerButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.registerButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.registerButton.Location = new System.Drawing.Point(161, 282);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(135, 45);
            this.registerButton.TabIndex = 1;
            this.registerButton.Text = "REGISTER";
            this.registerButton.UseVisualStyleBackColor = true;
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // passBox
            // 
            this.passBox.AcceptsTab = true;
            this.passBox.Location = new System.Drawing.Point(183, 144);
            this.passBox.Name = "passBox";
            this.passBox.PasswordChar = '*';
            this.passBox.Size = new System.Drawing.Size(218, 27);
            this.passBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria Math", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(38, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 111);
            this.label1.TabIndex = 4;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria Math", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(38, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 111);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password";
            // 
            // userBox
            // 
            this.userBox.AcceptsTab = true;
            this.userBox.Location = new System.Drawing.Point(183, 73);
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(218, 27);
            this.userBox.TabIndex = 6;
            // 
            // About_menu
            // 
            this.About_menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.About_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.about_strip});
            this.About_menu.Location = new System.Drawing.Point(0, 0);
            this.About_menu.Name = "About_menu";
            this.About_menu.Size = new System.Drawing.Size(473, 28);
            this.About_menu.TabIndex = 7;
            this.About_menu.Text = "menuStrip1";
            this.About_menu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.About_menu_ItemClicked);
            // 
            // about_strip
            // 
            this.about_strip.Name = "about_strip";
            this.about_strip.Size = new System.Drawing.Size(64, 24);
            this.about_strip.Text = "About";
            // 
            // loginPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 369);
            this.Controls.Add(this.userBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passBox);
            this.Controls.Add(this.registerButton);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.About_menu);
            this.MainMenuStrip = this.About_menu;
            this.Name = "loginPage";
            this.Text = "Login";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form_close);
            this.About_menu.ResumeLayout(false);
            this.About_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Button registerButton;
        private System.Windows.Forms.TextBox passBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox userBox;
        private System.Windows.Forms.MenuStrip About_menu;
        private System.Windows.Forms.ToolStripMenuItem about_strip;
    }
}