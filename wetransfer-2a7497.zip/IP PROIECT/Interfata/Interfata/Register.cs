﻿/**************************************************************************
 *                                                                        *
 *  File:        Register.cs                                              *
 *  Copyright:   (c) 2021, Lefter Ioan-Alexandru                          *
 *  Interface    Prodan Oana-Elena                                        *
 *  E-mail:      ioan-alexandru.lefter@student.tuiasi.ro                  *
 *  Description: Aceasta pagina permite unui nou utilizator sa se         *
 *               inregistreze in vederea simularii unui examen auto.      *
 *                                                                        *
 *  This program is free software; you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation. This program is distributed in the      *
 *  hope that it will be useful, but WITHOUT ANY WARRANTY; without even   *
 *  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   *
 *  PURPOSE. See the GNU General Public License for more details.         *
 *                                                                        *
 **************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Interfata
{
    /// <summary>
    /// In aceasta pagina un utilizator nou isi poate creea un cont. 
    ///     Atat parola cat si numele de utilizator trebuie sa contina
    ///     minim 3 caractere. 
    ///     La apasarea butonului submit se creeaza o noua inregistrare 
    ///     in fisierului utilizatori.xml 
    /// </summary>
    public partial class Register : Form
    {
        #region Constructors
        public Register()
        {
            InitializeComponent();
        }
        #endregion

        #region Events
        /// <summary>
        /// Butonul de submit. 
        ///     Se verifica datele introduse astfel incat sa corespunda 
        ///     din punct de vedere al dimensiunii. 
        ///     Daca datele sunt introduse bine atunci se scriu in utilizatori.xml
        ///     Dupa inregistrare se revine la pagina de login. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if (usernameBox.Text.ToString().Length < 3)
            {
                MessageBox.Show("Username trebuie să conțină minim 3 caractere!");
            }
            else if (passwordBox.Text.Length < 3)
            {
                MessageBox.Show("Parola trebuie să conțină minim 3 caractere!");
            }
            else
            {
                //daca inregistrarea este facuta cu succes, se va scrie contul in XML;
                XDocument Xdoc = new XDocument(new XElement("Users"));
                try
                {
                    Xdoc = XDocument.Load(Application.StartupPath.ToString() + @"/utilizatori.xml");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    Xdoc = new XDocument();
                }

                XElement xml = new XElement("users",
                               new XElement("username", usernameBox.Text),
                               new XElement("password", passwordBox.Text),
                               new XElement("name", numeBox.Text));

                if (Xdoc.Descendants().Count() > 0)
                {
                    Xdoc.Descendants().First().Add(xml);
                }
                else
                {
                    Xdoc.Add(xml);
                }

                try
                {
                    Xdoc.Save(Application.StartupPath.ToString() + @"/utilizatori.xml");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //Dupa inregistrare se deschide fereastra de login;
                Clear();
                this.Hide();
                loginPage log = new loginPage();
                log.Show();
            }


        }

        /// <summary>
        /// La apasarea butonul 'X' de pe fereastra se inchide aplicatia 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void form_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #region Methods
        private void Clear()
        {
            usernameBox.Clear();
            passwordBox.Clear();
            numeBox.Clear();
            emailBox.Clear();
        }
        #endregion

    }
}
