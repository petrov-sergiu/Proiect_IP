﻿/**************************************************************************
 *                                                                        *
 *  File:        Form1.cs                                                 *
 *  Copyright:   (c) 2021, Maftei Eduard-Ionut                            *
 *  Interface:   Prodan Oana-Elena                                        *
 *  E-mail:      eduard-ionut.maftei@student.tuiasi.ro                    *
 *  Description: Pagina de simulare examen auto                           *
 *                                                                        *
 *  This program is free software; you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation. This program is distributed in the      *
 *  hope that it will be useful, but WITHOUT ANY WARRANTY; without even   *
 *  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   *
 *  PURPOSE. See the GNU General Public License for more details.         *
 *                                                                        *
 **************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfata
{
    /// <summary>
    /// Creeaza simularea de examen 
    /// </summary>
    public partial class Form1 : Form
    {
        #region Fields

        //lista cu numarul intrebarilor
        List<int> nrIntrebare = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
                                                 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43,
                                                  44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62,
                                                  63, 64, 65, 66, 67, 68, 69, 70};
       
        //numarul intrebarii
        int qNum = 0;

        int i;

        int correctAnswer;
        int raspunsuriCorecte;
        int raspunsuriGresite;

        //numarul de intrebari dintr-un test(26)
        int totalQuestions;
        #endregion Fields

        #region Constructors
        public Form1()
        {
            InitializeComponent();
            StartGame();
            NextQuestion();
            totalQuestions = 26;
        }
        #endregion Constructors

        #region Events

        /// <summary>
        /// Fiecarui buton ii este atribuit un tag. 
        ///     Se verifica daca raspunsul dat este corect, 
        ///     caz in care se incrementeaza scorul. 
        ///     Se verifica rezultatul testului. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkAnswerEvent(object sender, EventArgs e)
        {

            var senderObject = (Button)sender;
            //Fiecarui buton ii este atribuit tag-ul respectiv;
            int buttonTag = Convert.ToInt32(senderObject.Tag);

            //Daca butonul apasat corespunde raspunsului corect atunci se incrementeaza scorul 
            if (buttonTag == correctAnswer)
            {
                raspunsuriCorecte++;
            }
            else
            {
                raspunsuriGresite++;
            }

            qNum++;

            if (raspunsuriGresite == 5)
            {
                MessageBox.Show("Sfârșit! " + Environment.NewLine +
                   "Ați picat examenul!");
                Restart();
            }
            //Daca se ajunge la numarul total de intrebari fara a pica examenul, acesta este promovat;
            else if (qNum == totalQuestions)
            {
                MessageBox.Show("Felicitari! Ati promovat examenul! " + Environment.NewLine +
                    "Ați obținut: " + raspunsuriCorecte);
                Restart();
            }
            //Trece la urmatoarea intrebare;
            NextQuestion();
            label.ForeColor = Color.FromArgb(0, 128, 0);
            label3.ForeColor = Color.FromArgb(255, 0, 0);

            //Tine scorul;
            label.Text = "Răspunsuri corecte: " + raspunsuriCorecte;
            label3.Text = "Răspunsuri greșite: " + raspunsuriGresite;
            label2.Text = "Întrebarea " + (qNum + 1) + " / " + totalQuestions;
        }
        #endregion Events

        #region Methods

        //resetare
        private void Restart()
        {
            raspunsuriGresite = 0;
            raspunsuriCorecte = 0;
            qNum = 0;
            i = 0;
            StartGame();
        }


        //Trece la urmatoarea intrebare;
        private void NextQuestion()
        {
            if (qNum < nrIntrebare.Count)
            {
                i = nrIntrebare[qNum];
            }
            else
            {
                Restart();
            }

            //intrebarile salvate
            switch (i)
            {

                case 1:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce tendință prezintă un autoturism cu tractiune pe spate, dacă accelerați prea puternic in curbă?";
                    button1.Text = "A. autoturismul urmează, fără deviere, cursa volanului";
                    button2.Text = "B. autoturismul tinde să derapeze cu spatele spre exteriorul curbei";
                    button3.Text = "C. roțile din față se învârtesc in gol";

                    correctAnswer = 2;

                    break;


                case 2:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligații are conducătorul de autovehicule când circulă pe un drum public?";
                    button1.Text = "A. să circule numai dacă verificarea medicală lunară este efectuată";
                    button2.Text = "B. să circule numai pe sectoarele de drum pe care îi este permis accesul și să respecte normele referitoare la masele totale maxime autorizate admise de autoritatea competentă";
                    button3.Text = "C. să se informeze din timp, la administratorii de drum, în legătură cu eventualele limite maxime și minime de viteză";

                    correctAnswer = 2;

                    break;


                case 3:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce se înțelege prin conducere ecologică a unui autovehicul?";
                    button1.Text = "A. obligația de a folosi în permanență carburant biodegradabil";
                    button2.Text = "B. deplasări urbane cu bicicleta, pe jos sau cu alte mijloace care nu poluează atmosfera";
                    button3.Text = "C. un ansamblu de măsuri comportamentale, de control sau de verificare a  vehiculului, prin care se realizează o importantă economie de energie și protecția mediului";

                    correctAnswer = 3;

                    break;

                case 4:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "În rănile cu hemoragie se va avea în vedere, în faza inițială:";
                    button1.Text = "A. curățarea și pansarea rănii";
                    button2.Text = "B. pansarea rănii";
                    button3.Text = "C. oprirea hemoragiei";

                    correctAnswer = 3;

                    break;


                case 5:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "La semnalul polițistului situat într-o intersecție, cu brațul ridicat vertical, aveți obligația:";
                    button1.Text = "A. să circulaţi cu prudenţă maximă";
                    button2.Text = "B. să reduceţi viteza";
                    button3.Text = "C. să opriţi, indiferent din ce direcţie circulaţi";

                    correctAnswer = 3;

                    break;


                case 6:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Care este deosebirea dintre oprire şi staţionare?";
                    button1.Text = "A. niciuna";
                    button2.Text = "B. deosebirea constă în durata de imobilizare a vehiculului";
                    button3.Text = "C. deosebirea constă în modul de aşezare şi asigurare a autovehiculului pe drum";

                    correctAnswer = 2;

                    break;


                case 7:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligaţii vă revin la semnalul agentului de cale ferată de la trecerile la nivel, executat cu un dispozitiv cu lumină roşie ori cu bastonul fluorescent-reflectorizant?";
                    button1.Text = "A. să reduceţi viteza doar până traversaţi calea ferată";
                    button2.Text = "B. să opriţi autovehiculu";
                    button3.Text = "C. să reduceţi viteza şi să opriţi numai dacă circulă un vehicul feroviar";

                    correctAnswer = 2;

                    break;


                case 8:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "La apropierea de staţiile prevăzute cu alveolă, când circulaţi pe banda de lângă acostament, iar conducătorul autovehiculului de transport public de persoane semnalizează pornirea din staţie:";
                    button1.Text = "A. opriţi obligatoriu";
                    button2.Text = "B. reduceţi viteza şi, la nevoie, opriţi";
                    button3.Text = "C. măriţi viteza";

                    correctAnswer = 2;

                    break;


                case 9:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Pe o autostradă cu trei benzi, s-a blocat circulaţia. Pe unde vor circula vehiculele de intervenţie?";
                    button1.Text = "A. pe banda de urgenţă";
                    button2.Text = "B. între banda din stânga şi banda din mijloc";
                    button3.Text = "C. între banda din dreapta şi banda din mijloc";

                    correctAnswer = 1;

                    break;


                case 10:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Utilizarea sistemului de climatizare are ca efect:";
                    button1.Text = "A. creşterea consumului de combustibil";
                    button2.Text = "B. reducerea consumului de combustibil";
                    button3.Text = "C. scăderea puternică a gradului de confort";

                    correctAnswer = 1;

                    break;


                case 11:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Pentru a conduce ecologic un autovehicul, se recomandă:";
                    button1.Text = "A. utilizarea climatizării numai în cazul traseelor scurte";
                    button2.Text = "B. utilizarea climatizării numai pe timp de noapte";
                    button3.Text = "C. utilizarea climatizării numai în situaţiile absolut necesare";

                    correctAnswer = 3;

                    break;


                case 12:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Când sunteţi obligat să păstraţi o distanţă corespunzătoare faţă de cel care rulează în faţa dumneavoastră?";
                    button1.Text = "A. numai atunci când nu aveţi experienţă în conducere";
                    button2.Text = "B. numai dacă autovehiculul pe care îl conduceţi nu are frânele eficiente";
                    button3.Text = "C. în orice situaţie";

                    correctAnswer = 3;

                    break;


                case 13:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Semnalul poliţistului rutier aflat într-un autovehicul al poliţiei, efectuat cu braţul, cu sau fără baston reflectorizant, scos pe partea laterală dreaptă a vehiculului, semnifică:";
                    button1.Text = "A. oprire pentru conducătorii vehiculelor care circulă în spatele autovehiculului poliţiei";
                    button2.Text = "B. reducerea vitezei de către cei care circulă în spatele autovehiculului poliţiei";
                    button3.Text = "C. semnalul se adresează celor care circulă din sens opus";

                    correctAnswer = 1;

                    break;


                case 14:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Copiii cu vârste de până la 12 ani pot fi transportaţi:";
                    button1.Text = "A. pe scaunul din faţă al autovehiculului, dacă sunt ţinuţi în braţe de persoane majore";
                    button2.Text = "B. pe scaunul din faţă al autovehiculului, având fixată centura de siguranţă";
                    button3.Text = "C. pe bancheta din spate a autovehiculului, având fixată centura de siguranţă, adaptată greutăţii şi dimensiunilor lor";

                    correctAnswer = 3;

                    break;


                case 15:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Dezinfecţia plăgilor ce necesită a fi pansate se face cu:";
                    button1.Text = "A. apă oxigenată sau iod";
                    button2.Text = "B. ser fiziologic";
                    button3.Text = "C. apă potabilă";

                    correctAnswer = 1;

                    break;


                case 16:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum procedează conducătorul de autovehicul atunci când, apropiindu-se de o trecere la nivel cu calea ferată, prevăzută cu bariere ori semibariere, cele două lumini roşii funcţionează intermitentalternativ? ";
                    button1.Text = "A. continuă deplasarea, dacă barierele nu sunt coborâte";
                    button2.Text = "B. opreşte, deoarece barierele sunt închise sau urmează să coboare";
                    button3.Text = "C. continuă deplasarea fără interdicţie, deoarece luminile semnalizează doar prezenţa unei treceri la nivel cu calea ferată";

                    correctAnswer = 2;

                    break;


                case 17:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Care este regula priorităţii de trecere la intersecţia a două drumuri de aceeaşi categorie, cu circulaţie nedirijată?";
                    button1.Text = "A. prioritatea de dreapta";
                    button2.Text = "B. prioritatea primului sosit";
                    button3.Text = "C. prioritatea de drum principal";

                    correctAnswer = 1;

                    break;


                case 18:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "În faţa dvs. s-a produs un accident rutier care este cercetat de poliţie, iar circulaţia se desfăşoară anevoios, pe un singur sens. Cum veţi proceda? ";
                    button1.Text = "A. vă continuaţi drumul cu atenţie, respectând indicaţiile poliţistului rutier";
                    button2.Text = "B. vă continuaţi drumul cu viteză sporită, pentru a nu bloca traficul rutier";
                    button3.Text = "C. reduceţi viteza şi opriţi în locul accidentului, pentru a vedea ce s-a întâmplat";

                    correctAnswer = 1;

                    break;


                case 19:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligaţii aveţi la întâlnirea indicatorului „Biciclişti”?";
                    button1.Text = "A. să reduceţi viteza la maximum 30 km/h";
                    button2.Text = "B. să circulaţi cu atenţie şi, dacă este cazul, acordaţi prioritate de trecere bicicliştilor care circulă pe pista special destinată";
                    button3.Text = "C. nu aveţi nicio obligaţie, bicicliştii vă vor acorda prioritate";

                    correctAnswer = 2;

                    break;


                case 20:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Este permisă oprirea voluntară a autovehiculului în tuneluri?";
                    button1.Text = "A. da";
                    button2.Text = "B. nu";
                    button3.Text = "C. numai dacă lungimea tunelului depăşeşte 1000 m";

                    correctAnswer = 2;

                    break;


                case 21:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "În ce locuri circulaţia cu viteză duce adeseori la accidente?";
                    button1.Text = "A. în intersecţii";
                    button2.Text = "B. în parcări";
                    button3.Text = "C. în poligoanele auto";

                    correctAnswer = 1;

                    break;


                case 22:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce trebuie să facă un conducător de vehicul pentru ca depăşirea să fie considerată regulamentară? ";
                    button1.Text = "A. să se asigure că manevra poate fi executată în condiţii de siguranţă, după care să semnalizeze intenţia de schimbare a poziţiei de mers şi să efectueze depăşirea";
                    button2.Text = "B. să semnalizeze din timp intenţia de schimbare a direcţiei de mers";
                    button3.Text = "C. să mărească viteza de deplasare, astfel încât să scurteze timpul de realizare a depăşirii";

                    correctAnswer = 1;

                    break;


                case 23:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Vă apropiaţi de o trecere la nivel cu calea ferată curentă fără bariere, în traversarea căreia s-a angajat o căruţă aflată în faţa dvs.În această situaţie puteţi efectua depăşirea?";
                    button1.Text = "A. da, dacă aceasta nu a ajuns încă la linia de tren";
                    button2.Text = "B. da, întrucât căruţa este un vehicul lent";
                    button3.Text = "C. nu";

                    correctAnswer = 3;

                    break;


                case 24:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Care autovehicule pot fi echipate cu lumini speciale de avertizare de culoare albastră?";
                    button1.Text = "A. legea nu prevede";
                    button2.Text = "B. orice autovehicul pentru care se obţine aprobarea poliţiei rutiere";
                    button3.Text = "C. vehiculele aparţinând poliţiei, jandarmeriei şi poliţiei de frontieră";

                    correctAnswer = 3;

                    break;


                case 25:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Dacă circulaţi pe un drum naţional european (E), vă este interzis:";
                    button1.Text = "A. să folosiţi pe timpul zilei luminile de întâlnire";
                    button2.Text = "B. să opriţi pe partea carosabilă";
                    button3.Text = "C. să depăşiţi";

                    correctAnswer = 2;

                    break;


                case 26:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Când este permisă trecerea la nivel cu o cale ferată fără bariere, prevăzută cu semnalizare luminoasă, dacă tocmai a trecut un tren?";
                    button1.Text = "A. după ce s-a stins lumina roşie intermitentă";
                    button2.Text = "B. după ce a trecut ultimul vagon";
                    button3.Text = "C. atunci când pleacă vehiculele aflate de cealaltă parte a căii ferate";

                    correctAnswer = 1;

                    break;


                case 27:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Permisul de conducere se restituie, după expirarea perioadei de suspendare şi promovarea testului de cunoaştere a regulilor de circulaţie, dacă a fost reţinut pentru:";
                    button1.Text = "A. neacordarea priorităţii de trecere vehiculelor care au acest drept, dacă prin aceasta s-a produs un accident de circulaţie soldat cu pagube materiale";
                    button2.Text = "B. nefolosirea în timpul mersului a centurii de siguranţă";
                    button3.Text = "C. utilizarea excesivă a ştergătoarelor de parbriz";

                    correctAnswer = 1;

                    break;


                case 28:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum este bine să procedaţi atunci când, circulând în spatele unui biciclist, constataţi că acesta doreşte să schimbe direcţia de mers?";
                    button1.Text = "A. semnalizaţi sonor intenţia de a-l depăşi";
                    button2.Text = "B. îi asiguraţi condiţii pentru realizarea manevrei";
                    button3.Text = "C. nu aveţi nicio obligaţie, întrucât acesta este un vehicul foarte lent";

                    correctAnswer = 2;

                    break;


                case 29:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Semnalul agenţilor căilor ferate, executat cu un fanion roşu, aflaţi la trecerea la nivel cu o cale ferată industrială din oraşe, vă obligă:";
                    button1.Text = "A. să reduceţi viteza, să vă asiguraţi, iar dacă trenul este la mai mult de 50 m de pasaj, să treceţi cu atenţie";
                    button2.Text = "B. să opriţi";
                    button3.Text = "C. nu aveţi nicio obligaţie, deoarece agentul dirijează manevrele garniturii de tren";

                    correctAnswer = 2;

                    break;


                case 30:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce pericole pot apărea prin nefolosirea centurii de siguranţă?";
                    button1.Text = "A. chiar şi la o viteză de coliziune de aproximativ 20 km/h, există riscul unei accidentări";
                    button2.Text = "B. pericolele pot apărea la o viteză de peste 60 km/h";
                    button3.Text = "C. pericolul de accidentare este exclus";

                    correctAnswer = 1;

                    break;


                case 31:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "La ce distanţă de trecerea la nivel cu calea ferată sunt instalate panourile suplimentare de avertizare? ";
                    button1.Text = "A. primul la 90 m, al doilea la 60 m şi al treilea la 30 m";
                    button2.Text = "B. primul la 200 m, al doilea la 150 m şi al treilea la 100 m";
                    button3.Text = "C. primul la 150 m, al doilea la 100 m şi al treilea la 50 m";

                    correctAnswer = 3;

                    break;


                case 32:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Puteţi trece cu autovehiculul peste o linie continuă dacă:";
                    button1.Text = "A. linia continuă este însoţită de una discontinuă, iar aceasta din urmă este mai apropiată de sensul dvs. de deplasare";
                    button2.Text = "B. aceasta este aplicată pe drumuri cu mai mult de o bandă pe sensul de mers";
                    button3.Text = "C. aceasta separă sensurile de circulaţie";

                    correctAnswer = 1;

                    break;


                case 33:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Care sunt vehiculele care au prioritate de trecere într-o intersecţie dirijată?";
                    button1.Text = "A. autocamioanele de mare tonaj";
                    button2.Text = "B. vehiculele aparţinând Protecţiei Civile, semnalizate ca atare";
                    button3.Text = "C. vehiculele aparţinând Serviciului de Ambulanţă, când au în funcţiune semnalele speciale luminoase şi sonore";

                    correctAnswer = 3;

                    break;


                case 34:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce trebuie să faceţi pentru a evita un accident de circulaţie?";
                    button1.Text = "A. să nu conduceţi autoturismul decât atunci când probleme grave impun acest lucru";
                    button2.Text = "B. să vă asiguraţi întotdeauna un partener care să cunoască bine traseul parcurs";
                    button3.Text = "C. să anticipaţi şi să contracaraţi la timp manevrele imprudente ale partenerilor de drum şi să respectaţi permanent regulile de circulaţie";

                    correctAnswer = 3;

                    break;


                case 35:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Când sunteţi obligat să opriţi autovehiculul?";
                    button1.Text = "A. la semnalele îndrumătorilor de circulaţie ai Ministerului Apărări";
                    button2.Text = "B. la semnalele conducătorilor de vehicule care virează la dreapta";
                    button3.Text = "C. la semnalele conducătorilor vehiculelor care circulă din sens invers";

                    correctAnswer = 1;

                    break;


                case 36:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "La apariția defecțiunilor tehnice ale mecanismului e direcție se procedează astfel:";
                    button1.Text = "A. se apelează la cunoştinţe care au mai întâlnit astfel de situaţii";
                    button2.Text = "B. se continuă deplasarea, întrucât defecţiunea se datorează stării drumului public";
                    button3.Text = "C. se apelează numai la atelierele specializate, care au personal calificat";

                    correctAnswer = 3;

                    break;


                case 37:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce semnificaţie are lumina de culoare roşie a semaforului, atât pentru conducătorii de vehicule, cât şi pentru pietoni?";
                    button1.Text = "A. îi obligă atât pe conducători, cât şi pe pietoni să se oprească";
                    button2.Text = "B. îi obligă pe conducători să oprească, iar pe pietoni să traverseze cu prudenţă";
                    button3.Text = "C. permite vehiculelor să vireze la dreapta, cu respectarea priorităţii";

                    correctAnswer = 1;

                    break;


                case 38:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligaţii are conducătorul unui autovehicul, dacă a obţinut permis de conducere de mai puţin de un an?";
                    button1.Text = "A. să circule cu semnul distinctiv aplicat regulamentar";
                    button2.Text = "B. să emită semnale acustice ori de câte ori efectuează o depăşire";
                    button3.Text = "C. să circule cu faza de drum în funcţiune, inclusiv pe timp de zi";

                    correctAnswer = 1;

                    break;


                case 39:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Conducătorul unui autovehicul angajat într-un accident din care a rezultat moartea sau rănirea unei persoane poate părăsi locul faptei fără încuviinţarea poliţiei? ";
                    button1.Text = "A. da, dacă autovehiculul a blocat circulaţia";
                    button2.Text = "B. da, dacă accidentul nu s-a produs din vina sa";
                    button3.Text = "C. nu, întrucât fapta constituie infracţiune";

                    correctAnswer = 3;

                    break;


                case 40:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum trebuie să procedeze conducătorul de autovehicul atunci când, într-o intersecţie, întâlneşte un poliţist orientat cu faţa spre el, care îi face semn să - şi continue deplasarea? ";
                    button1.Text = "A. opreşte până când poliţistul îşi schimbă poziţia";
                    button2.Text = "B. fiind un semnal în afara Regulamentului, opreşte şi aşteaptă revenirea la o poziţie care să-i permită continuarea drumului";
                    button3.Text = "C. se conformează semnalului poliţistului";

                    correctAnswer = 3;

                    break;


                case 41:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "În cazul implicării într-un accident, puteţi părăsi locul acestuia fără încuviinţarea poliţiei, dacă a rezultat vătămarea integrităţii corporale a unei persoane?";
                    button1.Text = "A. da, dacă accidentul nu s-a produs din vina dvs";
                    button2.Text = "B. da, în cazul în care autoturismul dvs. nu a fost avariat";
                    button3.Text = "C. nu";

                    correctAnswer = 3;

                    break;


                case 42:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Avertizarea sonoră se foloseşte:";
                    button1.Text = "A. ori de câte ori este necesar, pentru evitarea unui pericol imediat";
                    button2.Text = "B. la trecerea pe lângă biciclişti";
                    button3.Text = "C. în localităţi, la apropierea de o trecere pentru pietoni";

                    correctAnswer = 1;

                    break;


                case 43:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum trebuie să procedaţi atunci când intraţi, pe timp de zi, într-un tunel iluminat necorespunzător?";
                    button1.Text = "A. claxonaţi";
                    button2.Text = "B. aprindeţi luminile de întâlnire";
                    button3.Text = "C. aprindeţi lumina intermitentă de avertizare";

                    correctAnswer = 2;

                    break;


                case 44:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligaţii aveţi la întâlnirea indicatorului „Animale”?";
                    button1.Text = "A. să reduceţi viteza numai la semnalul celor care însoţesc animale";
                    button2.Text = "B. circulaţi cu atenţie şi, dacă se impune, reduceţi viteza";
                    button3.Text = "C. nu aveţi nicio obligaţie, deoarece indicatorul se adresează persoanelor care însoţesc animale";

                    correctAnswer = 2;

                    break;


                case 45:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Din sens opus, un vehicul depăşeşte un altul şi nu poate reveni pe banda sa. Cum vă comportaţi corect?";
                    button1.Text = "A. circulaţi mai departe cu viteză mărită";
                    button2.Text = "B. reduceţi viteza şi vă angajaţi mult spre dreapta";
                    button3.Text = "C. avertizaţi cu farurile vehiculele care circulă din sens opus";

                    correctAnswer = 2;

                    break;


                case 46:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "În cazul unui accident în care victima şi-a pierdut cunoştinţa, prima măsură va fi:";
                    button1.Text = "A. să administraţi medicamente din trusa de prim ajutor";
                    button2.Text = "B. să imobilizaţi eventualele fracturi";
                    button3.Text = "C. să controlaţi respiraţia şi bătăile inimii";

                    correctAnswer = 3;

                    break;


                case 47:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Ce obligaţie îi revine conducătorului de vehicul care schimbă direcţia de mers la dreapta, la semnalul verde al semaforului, în timp ce pietonii sunt angajaţi la rândul lor în traversare?";
                    button1.Text = "A. să semnalizeze schimbarea direcţiei de mers şi să acorde prioritate de trecere pietonilor angajaţi în traversarea străzii pe care urmează să intre, pe sensul său de mers";
                    button2.Text = "B. să semnalizeze schimbarea direcţiei de mers şi să-şi continue deplasarea cu prudenţă, pietonii fiind obligaţi să-i cedeze trecerea";
                    button3.Text = "C. să semnalizeze schimbarea direcţiei de mers şi să păstreze o distanţă laterală suficientă faţă de bordura din dreapta";

                    correctAnswer = 1;

                    break;


                case 48:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Marcajul longitudinal continuu, aplicat pe axul drumului, permite încălcarea lui:";
                    button1.Text = "A. numai de către conducătorii de motociclete şi mopede";
                    button2.Text = "B. numai de către vehiculele cu gabarit depăşit";
                    button3.Text = "C. nu, în nicio situaţie";

                    correctAnswer = 3;

                    break;


                case 49:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Când aveţi voie să fiţi agresiv în timpul conducerii pe drumurile publice?";
                    button1.Text = "A. atunci când cel din faţă rulează cu viteză redusă, fără motiv întemeiat";
                    button2.Text = "B. în nicio situaţie, indiferent de ceea ce se întâmplă cu ceilalţi participanţi la trafic";
                    button3.Text = "C. atunci când cel din faţă v-a făcut semne obscene";

                    correctAnswer = 2;

                    break;


                case 50:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum procedaţi atunci când circulaţi în afara localităţilor, pe un drum cu o singură bandă pe sens, şi întâlniţi un vehicul lent, lung sau greu pe care nu puteţi să îl depăşiţi?";
                    button1.Text = "A. îl semnalizaţi pe cel de la volan prin mijloacele de avertizare sonoră şi luminoasă";
                    button2.Text = "B. opriţi şi lăsaţi vehiculul respectiv să se îndepărteze";
                    button3.Text = "C. vă deplasaţi în urma acestuia, până când manevra de depăşire se poate efectua";

                    correctAnswer = 3;

                    break;


                case 51:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Purtarea centurii de siguranţă este obligatorie în timpul circulaţiei pe drumurile din localităţi?";
                    button1.Text = "A. nu";
                    button2.Text = "B. da, numai de către conducătorul autovehiculului";
                    button3.Text = "C. da, de către cel de la volan şi de către pasagerii care ocupă locurile prevăzute cu asemenea dispozitive";

                    correctAnswer = 3;

                    break;


                case 52:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum vă asiguraţi că nu există niciun pericol atunci când manevraţi autoturismul înapoi?";
                    button1.Text = "A. aprindeţi lanterna de ceaţă din spate";
                    button2.Text = "B. claxonaţi înainte de a pleca";
                    button3.Text = "C. vă asiguraţi din faţă, din spate şi din lateral";

                    correctAnswer = 3;

                    break;


                case 53:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Când constataţi că aveţi anumite probleme cu vederea, trebuie:";
                    button1.Text = "A. să vă cumpăraţi ochelari de vedere cu caracteristici superioare";
                    button2.Text = "B. să evitaţi conducerea autovehiculului până când sunteţi consultat de medicul specialist, urmând să vă conformaţi sfaturilor acestuia";
                    button3.Text = "C. să conduceţi folosind lumina de drum chiar şi în localităţi sau când din sens opus se apropie alte vehicule";

                    correctAnswer = 2;

                    break;


                case 54:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum este definită depăşirea?";
                    button1.Text = "A. trecerea unui vehicul pe lângă altul, când circulă în acelaşi sens, dar pe o bandă alăturată";
                    button2.Text = "B. manevra prin care un vehicul trece înaintea altui vehicul ori pe lângă un obstacol, aflat pe acelaşi sens de circulaţie, prin schimbarea direcţiei de mers şi ieşirea de pe banda de circulaţie sau din şirul de vehicule în care s-a aflat iniţial";
                    button3.Text = "C. trecerea unui vehicul prin dreptul altuia";

                    correctAnswer = 2;

                    break;


                case 55:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum se procedează cu accidentatul readus la viaţă prin resuscitare cardio-respiratorie?";
                    button1.Text = "A. se va transporta la domiciliu sau la locul de muncă";
                    button2.Text = "B. se va transporta întotdeauna la o unitate medicală specializată";
                    button3.Text = "C. se va aştepta sosirea poliţiei rutiere";

                    correctAnswer = 2;

                    break;

                case 56:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum veţi proceda corect dacă, la apropierea de o trecere la nivel cu o cale ferată prevăzută cu semibariere automate, semnalele sonore şi luminile roşii sunt în funcţiune?";
                    button1.Text = "A. reduceţi viteza şi opriţi înaintea semibarierelor";
                    button2.Text = "B. ocoliţi semibariera şi vă continuaţi drumul, dacă trenul nu se apropie";
                    button3.Text = "C. măriţi viteza pentru a nu fi surprinşi de închiderea semibarierei";

                    correctAnswer = 1;

                    break;


                case 57:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "La calea ferată curentă prevăzută cu bariere, atunci când semnalele sonore şi luminoase de culoare roşie sunt în funcţiune, sunteţi avertizat că:";
                    button1.Text = "A. instalaţia de închidere şi deschidere a barierelor nu funcţionează normal";
                    button2.Text = "B. trenul se apropie, urmând ca barierele să se închidă automat";
                    button3.Text = "C. trebuie să traversaţi de urgenţă calea ferată";

                    correctAnswer = 2;

                    break;


                case 58:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cât timp trebuie menţinută semnalizarea schimbării direcţiei de mers?";
                    button1.Text = "A. 10 secunde de la începerea manevrei";
                    button2.Text = "B. pe întreaga durată a executării manevrei";
                    button3.Text = "C. legea nu prevede nimic cu privire la acest aspect";

                    correctAnswer = 2;

                    break;


                case 59:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum acţionaţi în cazul unui accidentat a cărui inimă s-a oprit?";
                    button1.Text = "A. plecaţi, întrucât nu se mai poate face nimic";
                    button2.Text = "B. începeţi compresia artificială a inimii şi respiraţia artificială";
                    button3.Text = "C. mişcaţi energic accidentatul, pentru a-şi reveni";

                    correctAnswer = 2;

                    break;


                case 60:
                    pictureBox1.Image = Properties.Resources.basic;
                    label1.Text = "Cum trebuie să procedaţi atunci când intenţionaţi să finalizaţi o depăşire?";
                    button1.Text = "A. semnalizaţi revenirea şi efectuaţi manevra în condiţii de siguranţă";
                    button2.Text = "B. după reîncadrare, semnalizaţi cu luminile de avarie";
                    button3.Text = "C. claxonaţi şi vă angajaţi pe partea dreaptă, direct în faţa vehiculului depăşit";

                    correctAnswer = 1;

                    break;


                case 61:
                    pictureBox1.Image = Properties.Resources._61;
                    label1.Text = "Care dintre autovehicule îşi poate continua deplasarea?";
                    button1.Text = "A. toate trei";
                    button2.Text = "B. autobuzul şi autocamionul";
                    button3.Text = "C. autoturismul";

                    correctAnswer = 2;

                    break;


                case 62:
                    pictureBox1.Image = Properties.Resources._62;
                    label1.Text = "Ce semnificaţie are indicatorul din imagine?";
                    button1.Text = "A. urmează un sector de drum îngustat temporar";
                    button2.Text = "B. este interzisă schimbarea direcţiei de mers la dreapta în prima intersecţie";
                    button3.Text = "C. urmează o intersecţie cu un drum fără prioritate";

                    correctAnswer = 3;

                    break;


                case 63:
                    pictureBox1.Image = Properties.Resources._63;
                    label1.Text = "Indicatorul nu permite schimbarea direcţiei de mers spre stânga:";
                    button1.Text = "A. în intersecţia înaintea căreia este instalat";
                    button2.Text = "B. în toate intersecţiile, până la apariţia indicatorului „Sfârşitul tuturor restricţiilor”";
                    button3.Text = "C. la 200 m de la locul în care este instalat acesta";

                    correctAnswer = 1;

                    break;


                case 64:
                    pictureBox1.Image = Properties.Resources._64;
                    label1.Text = "Este permisă depăşirea în situaţia dată?";
                    button1.Text = "A. da, deoarece axul drumului este marcat cu linie continuă";
                    button2.Text = "B. da, deoarece linia discontinuă vă este cea mai apropiată de direcţia de mers";
                    button3.Text = "C. nu, deoarece autovehiculul din faţă nu vă permite depăşirea";

                    correctAnswer = 2;

                    break;


                case 65:
                    pictureBox1.Image = Properties.Resources._65;
                    label1.Text = "În această situaţie, intenţionaţi să viraţi pe prima stradă la dreapta. Ce obligaţii aveţi?";
                    button1.Text = "A. opriţi, vă asiguraţi, apoi schimbaţi direcţia de mers spre dreapta";
                    button2.Text = "B. ocoliţi sensul giratoriu, apoi schimbaţi direcţia de mers spre dreapta";
                    button3.Text = "C. semnalizaţi intenţia de a executa manevra, vă asiguraţi, vă angajaţi cât mai aproape de marginea din dreapta, apoi viraţi la dreapta";

                    correctAnswer = 3;

                    break;


                case 66:
                    pictureBox1.Image = Properties.Resources._66;
                    label1.Text = "Cum procedaţi în această situaţie?";
                    button1.Text = "A. se recomandă să măriţi atenţia";
                    button2.Text = "B. opriţi";
                    button3.Text = "C. acceleraţi, pentru a nu fi surprins de căderea pietrelor";

                    correctAnswer = 1;

                    break;


                case 67:
                    pictureBox1.Image = Properties.Resources._67;
                    label1.Text = "Ce autovehicul îşi poate continua deplasarea în imaginea prezentată?";
                    button1.Text = "A. autocamionul";
                    button2.Text = "B. autoturismul verde";
                    button3.Text = "C. autoturismul roşu";

                    correctAnswer = 3;

                    break;


                case 68:
                    pictureBox1.Image = Properties.Resources._68;
                    label1.Text = "Indicatorul semnifică:";
                    button1.Text = "A. accesul interzis vehiculelor cu o înălţime mai mare de 3,5 m";
                    button2.Text = "B. accesul permis numai vehiculelor cu o lăţime mai mică de 3,5 m";
                    button3.Text = "C. distanţa minimă obligatorie dintre două vehicule";

                    correctAnswer = 1;

                    break;


                case 69:
                    pictureBox1.Image = Properties.Resources._69;
                    label1.Text = "Semnalul poliţistului indică:";
                    button1.Text = "A. reduceţi viteza";
                    button2.Text = "B. măriţi viteza";
                    button3.Text = "C. mergeţi cu prudenţă";

                    correctAnswer = 2;

                    break;


                case 70:
                    pictureBox1.Image = Properties.Resources._70;
                    label1.Text = "Poliţistul din intersecţie semnalizează conducătorul auto să mărească viteza. Cum trebuie să procedeze acesta?";
                    button1.Text = "A. să respecte semnalul poliţistului";
                    button2.Text = "B. să aştepte lumina verde a semaforului";
                    button3.Text = "C. să acorde prioritate, apoi să îşi continue deplasarea";

                    correctAnswer = 1;

                    break;

            }
        }

        //Porneste jocul;
        private void StartGame()
        {
            //se interschimba aleatoriu pozitia intrebarilor din lista
            var randomList = nrIntrebare.OrderBy(x => Guid.NewGuid()).ToList();
            nrIntrebare = randomList;
            label2.Text = "Întrebarea 1 / 26";

        }
        #endregion Methods
        
    }
}
