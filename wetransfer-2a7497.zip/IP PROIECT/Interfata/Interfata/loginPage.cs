﻿/**************************************************************************
*                                                                        *
*  File:        loginPage.cs                                             *
*  Copyright:   (c) 2021, Lefter Ioan-Alexandru                          *
*  Help:        Popescu Cristina-Elena                                   *  
*  Interfata:   Prodan Oana-Elena                                        *
*  E-mail:      ioan-alexandru.lefter@student.tuiasi.ro                  *
*  Description: Pagina de logare                                         *
*               Permite unui utilizator existent                         *
*                   sa intre in pagina principala                        *
*               Permite unui nou utilizator sa se inregistreze           *
*                                                                        *
*  This program is free software; you can redistribute it and/or modify  *
*  it under the terms of the GNU General Public License as published by  *
*  the Free Software Foundation. This program is distributed in the      *
*  hope that it will be useful, but WITHOUT ANY WARRANTY; without even   *
*  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   *
*  PURPOSE. See the GNU General Public License for more details.         *
*                                                                        *
**************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Interfata
{
    /// <summary>
    /// In aceasta pagina se verifica daca un utilizator exista in fisierul .xml.
    ///     Daca exista se permite logarea si implicit accesul la functionalitati. 
    ///     Daca utilizatorul introduce parola sau username-ul gresit se afiseaza
    ///     mesaje sugestive. 
    ///     Din aceasta pagina se poate accesa fereastra de inregistrare.
    /// </summary>
    
    public partial class loginPage : Form
    {
        #region Fields
        public string _xmlUtilizatori = "";
        public string _xmlParola = "";
        public string _xmlNume = "";
        #endregion Fields

        #region Constructors
        public loginPage()
        {
            InitializeComponent();
        }
        #endregion Constructors

        #region Events

        /// <summary>
        /// Butonul de login care verifica daca sunt respectate dimensiunile 
        ///     impuse precum si corectitudinea datelor introduse. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loginButton_Click(object sender, EventArgs e)
        {
            if (userBox.Text.Length < 3)
            {
                MessageBox.Show("Nume de utilizator invalid!");
            }
            else if (passBox.Text.Length < 3)
            {
                MessageBox.Show("Parolă invalidă!");
            }
            else
            {
                //Valorile introduse in interfata
                string user = userBox.Text;
                string pass = passBox.Text;

                XDocument doc = new XDocument();
                try
                {
                    doc = XDocument.Load(Application.StartupPath.ToString() + @"\utilizatori.xml");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //cautam in fisierul XML "users"
                var all = from x in doc.Descendants("users").Where
                               //selectam utilizatorul cu numele din Text Box 
                               (x => (string)x.Element("username") == userBox.Text)
                          select new
                          {
                              //salvam datele din XML
                              XMLuser = x.Element("username").Value,
                              XMLpwd = x.Element("password").Value,
                              XMLname = x.Element("name").Value
                          };

                //copiem valorile in variabilele din program 
                foreach (var x in all)
                {
                    _xmlUtilizatori = x.XMLuser;
                    _xmlParola = x.XMLpwd;
                    _xmlNume = x.XMLname;
                }

                //Verificare date autentificare
                if (user == _xmlUtilizatori)
                {
                    if (pass == _xmlParola)
                    {
                        MainPage mainPage = new MainPage();

                        PassInfo._userName = _xmlNume;

                        Clear();

                        this.Hide();
                        mainPage.Show();

                    }
                    else
                    {
                        MessageBox.Show("Parola greșită!");
                        Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Nume de utilizator greșit!");
                    Clear();
                }
            }
        }

        /// <summary>
        /// Butonul de inregistrare care permite accesul la pagina de inregistrare
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void registerButton_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            Clear();
            this.Hide();
            register.Show();
        }

        /// <summary>
        /// La apasarea butonul 'X' de pe fereastra se inchide aplicatia 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void form_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Butonul de help. La apasarea acestuia se afiseaza ferestra de help. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void About_menu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                Help.ShowHelp(this, "Help.chm");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion Events

        #region Methods
        //functia de eliberare a Text Box-ului
        private void Clear()
        {
            userBox.Clear();
            passBox.Clear();
        }
        #endregion

    } 
}
