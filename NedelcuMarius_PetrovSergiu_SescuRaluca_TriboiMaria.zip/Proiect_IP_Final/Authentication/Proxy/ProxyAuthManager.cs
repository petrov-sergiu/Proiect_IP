﻿
/**************************************************************************
 *                                                                        *
 *  File:        CommandGraph.cs                                          *
 *  Copyright:   (c) 2021, Triboi Maria Emanuela                          *
 *  E-mail:      maria-emanuela.triboi@student.tuiasi.ro                  *
 *  Website:     https://github.com/petrov-sergiu/Proiect_IP              *
 *  Description:  A graph full of commands ready to be used.              *
 *                                                                        *
 *  This code and information is provided "as is" without warranty of     *
 *  any kind, either expressed or implied, including but not limited      *
 *  to the implied warranties of merchantability or fitness for a         *
 *  particular purpose. You are free to use this source code in your      *
 *  applications as long as the original copyright notice is included.    *
 *                                                                        *
 **************************************************************************/

using System;

namespace Proxy
{
    ///<summary>
    /// Clasa ProxyAuthManager ce va gestiona interactiunea cu fisierul cu utilizatori.
    ///</summary>
    public class ProxyAuthManager : IAuthManager
    {

        private readonly RealAuthManager _realAuthManager;
        ///<summary>
        /// Constructorul clasei ProxyAuthManager.
        ///</summary>
        public ProxyAuthManager()
        {
            if (_realAuthManager == null)
            {
                _realAuthManager = new RealAuthManager();
            }
        }

        ///<summary>
        /// Metoda ce va apela alte doua metode ce verifica daca utilizatorul exista. 
        /// In caz afirmativ, metoda va loga utilizatorul.
        ///</summary>
        public bool Login(string username, string password)
        {
            if (_realAuthManager.UserExists(username) && _realAuthManager.PassIsRight(password))
            {
                return true;
            }
            return false;
        }
        ///<summary>
        /// Metoda ce va adauga utilizatorul in fisier.
        ///</summary>
        public void AddUser(string user, string pass)
        {
            _realAuthManager.AddUser(user, pass);
        }

        ///<summary>
        /// Metoda ce va verifica daca utilizatorul exista.
        ///</summary>
        public bool UserExists(string user)
        {
            return _realAuthManager.UserExists(user);
        }
    }
}
