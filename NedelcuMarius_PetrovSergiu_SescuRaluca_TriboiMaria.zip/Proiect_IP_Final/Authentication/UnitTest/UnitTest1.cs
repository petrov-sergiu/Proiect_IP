﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ManagerTask;
using Task;
using Authentication;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ManageClass a = ManageClass.Instance();
            Assert.AreEqual(5, a.nr);
        }
        [TestMethod]
        public void TestExceptionCase()
        {
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere","",date1, date2, StatusTask.DONE, "a");

            Assert.AreEqual("descriere", _taskObject1.TaskDetails);
        }
        [TestMethod]
        public void Two_tasks_are_the_same()
        {
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 25);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreEqual(date2, _taskObject1.TaskEndTime);
        }

        [TestMethod]
        public void Two_tasks_are_not_the_same()
        {
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            TaskClass _taskObject2 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreNotEqual(_taskObject1, _taskObject2);
        }
        [TestMethod]
        public void TestTask1()
        {
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 25);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreEqual("nume", _taskObject1.TaskName);
        }

        [TestMethod]
        public void TestTask2()
        {
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject2 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreNotEqual("DONE", _taskObject2.TasProgress);
        }
        [TestMethod]
        public void TestMethod2()
        {
            DrawTask a = new DrawTask();
            Assert.AreEqual(5, a.nr);
        }

        [TestMethod]
        public void TestMethod_Criptare()
        {
            Assert.AreEqual("jLIjfQZ5yojbZGTqxg2pY0VROWQ=", Proxy.Cryptography.HashString("12345"));
        }
        [TestMethod]
        public void TestAdaugareTask()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreEqual("task adaugat", a.AddTask(_taskObject1));
        }
        [TestMethod]
        public void TestAdaugareTask1()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            a.AddTask(_taskObject1);
            Assert.AreEqual("Exista deja", a.AddTask(_taskObject1));
        }
        [TestMethod]
        public void TestDeleteTask()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            a.AddTask(_taskObject1);
            Assert.AreEqual("Task Sters", a.DeleteTask(_taskObject1));
        }
        [TestMethod]
        public void TestDeleteTask1()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreEqual("Task inexistent", a.DeleteTask(_taskObject1));
        }
        [TestMethod]
        public void TestContainsTask()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject1 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            a.AddTask(_taskObject1);
            Assert.AreEqual(true, a.Contains(_taskObject1));
        }
        [TestMethod]
        public void TestContainsTask1()
        {
            ManageClass a = ManageClass.Instance();
            DateTime date1 = new DateTime(2015, 12, 25);
            DateTime date2 = new DateTime(2015, 12, 26);
            TaskClass _taskObject2 = new TaskClass("nume", "descriere", "", date1, date2, StatusTask.DONE, "");
            Assert.AreNotEqual(false, a.Contains(_taskObject2));
        }
    }
}
