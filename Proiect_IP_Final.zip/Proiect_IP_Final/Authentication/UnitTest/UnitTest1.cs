﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ManagerTask;
namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ManageClass a = ManageClass.Instance();
            Assert.AreEqual(5, a.nr);
        }
    }
}
