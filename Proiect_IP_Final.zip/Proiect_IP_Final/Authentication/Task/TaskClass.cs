﻿using System;

namespace Task
{
    public enum StatusTask
    {
        TODO,
        DOING,
        DONE
    }
    public class TaskClass
    {
        private string _taskName;
        private string _taskDetails;
        private string _pathImage;
        private StatusTask _progressTask;
        private DateTime _startTask;
        private DateTime _endDate;
        private string _numeUser;

        public TaskClass(string taskName, string taskDetails, DateTime startTask, DateTime endDate, StatusTask progressTask, String numUser)
        {
            _taskName = taskName;
            _taskDetails = taskDetails;

            _startTask = startTask;
            _endDate = endDate;
            _progressTask = progressTask;
            _numeUser = numUser;
        }

        public TaskClass(string taskName, string taskDetails, string path, DateTime startTask, DateTime endDate, StatusTask progressTask, String numUser)
        {
            _taskName = taskName;
            _taskDetails = taskDetails;
            _pathImage = path;
            _startTask = startTask;
            _endDate = endDate;
            _progressTask = progressTask;
            _numeUser = numUser;
        }

        public string TaskName
        {
            get { return _taskName; }
            set { _taskName = value; }
        }
        public string TaskUserName
        {
            get { return _numeUser; }
            set { _numeUser = value; }
        }

        public string TaskDetails
        {
            get { return _taskDetails; }
            set { _taskDetails = value; }
        }

        public string TaskPathImage
        {
            get { return _pathImage; }
            set { _pathImage = value; }
        }

        public StatusTask TasProgress
        {
            get { return _progressTask; }
            set { _progressTask = value; }
        }

        public DateTime TaskStartTime
        {
            get { return _startTask; }
            set { _startTask = value; }
        }

        public DateTime TaskEndTime
        {
            get { return _endDate; }
            set { _endDate = value; }
        }
    }
}
