﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proxy
{
    internal interface IAuthManager
    {

        bool UserExists(string user);
        void AddUser(string user, string pass);
    }
}
