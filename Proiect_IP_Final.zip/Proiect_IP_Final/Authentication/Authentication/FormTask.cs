﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Task;
using ManagerTask;

namespace Authentication
{
    public partial class FormTask : Form
    {
        public string _path;
        public TaskClass newTask;
        public string numeUtil = "";
        public FormTask()
        {
            InitializeComponent();
            comboBoxTaskStatus.Items.Add("TODO");
            comboBoxTaskStatus.Items.Add("DOING");
            comboBoxTaskStatus.Items.Add("DONE");
            AddButton.Enabled = true;
            ModifyButton.Enabled = false;
        }
        public FormTask(TaskClass t)
        {
            InitializeComponent();
            comboBoxTaskStatus.Items.Add("TODO");
            comboBoxTaskStatus.Items.Add("DOING");
            comboBoxTaskStatus.Items.Add("DONE");
            textBoxTaskName.Text = t.TaskName;
            dateTimePickerTaskStartDate.Value = t.TaskStartTime;
            dateTimePickerTaskFinishDate.Value = t.TaskEndTime;
            switch (t.TasProgress.ToString())
            {
                case "TODO":
                    comboBoxTaskStatus.SelectedIndex = 0;
                    break;
                case "DOING":
                    comboBoxTaskStatus.SelectedIndex = 1;
                    break;
                case "DONE":
                    comboBoxTaskStatus.SelectedIndex = 2;
                    break;
            }
            Image newImage = Image.FromFile("imagini/" + t.TaskPathImage);
            pictureBoxTaskPhoto.Image = (Image)(new Bitmap(newImage, new Size(135, 122)));
            AddButton.Enabled = false;
            ModifyButton.Enabled = true;
        }

        private void textBoxTaskName_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBoxTaskNote_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePickerTaskStartDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePickerTaskFinishDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBoxTaskPhoto_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxTaskStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            string name = textBoxTaskName.Text;
            DateTime startTime = dateTimePickerTaskStartDate.Value;
            DateTime endTime = dateTimePickerTaskFinishDate.Value;
            string description = richTextBoxTaskNote.Text;
            int statusIndex = comboBoxTaskStatus.SelectedIndex;
            StatusTask status;
            switch (statusIndex)
            {
                case 0:
                    status = StatusTask.TODO;
                    break;
                case 1:
                    status = StatusTask.DOING;
                    break;
                case 2:
                    status = StatusTask.DONE;
                    break;
                default:
                    MessageBox.Show("Adauga Status");
                    return;
            }

            if (name == "")
            {
                MessageBox.Show("Adauga Nume");
                return;
            }
            if (startTime == null)
            {
                MessageBox.Show("Adauga StartTime");
                return;
            }
            if (endTime == null)
            {
                MessageBox.Show("Adauga EndTime");
                return;
            }

            newTask = new TaskClass(name, description, _path, startTime, endTime, status, numeUtil);
            this.Close();
        }

        private void BrowsePhoto_Click(object sender, EventArgs e)
        {
            FormBrowse f = new FormBrowse();
            f.ShowDialog();
            _path = f.path;
            if (_path != "")
            {
                Image newImage = Image.FromFile("imagini/" + _path);
                pictureBoxTaskPhoto.Image = (Image)(new Bitmap(newImage, new Size(135, 122)));
            }
            else
                pictureBoxTaskPhoto.Image = null;
        }

        private void ModifyButton_Click(object sender, EventArgs e)
        {
            string name = textBoxTaskName.Text;
            DateTime startTime = dateTimePickerTaskStartDate.Value;
            DateTime endTime = dateTimePickerTaskFinishDate.Value;
            string description = richTextBoxTaskNote.Text;
            int statusIndex = comboBoxTaskStatus.SelectedIndex;
            StatusTask status;
            switch (statusIndex)
            {
                case 0:
                    status = StatusTask.TODO;
                    break;
                case 1:
                    status = StatusTask.DOING;
                    break;
                case 2:
                    status = StatusTask.DONE;
                    break;
                default:
                    MessageBox.Show("Adauga Status");
                    return;
            }

            if (name == "")
            {
                MessageBox.Show("Adauga Nume");
                return;
            }
            if (startTime == null)
            {
                MessageBox.Show("Adauga StartTime");
                return;
            }
            if (endTime == null)
            {
                MessageBox.Show("Adauga EndTime");
                return;
            }

            newTask = new TaskClass(name, description, _path, startTime, endTime, status, numeUtil);
            this.Close();
        }
    }
}
